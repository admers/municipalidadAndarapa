create procedure Eliminar_Personal(IN cod int)
BEGIN
DELETE FROM slider WHERE idslider = cod;
END;

